package com.hotelmanagement.model;

public enum RoomStatus {
	FREE, OCCUPIED, CLEANING_PROCESS
}
