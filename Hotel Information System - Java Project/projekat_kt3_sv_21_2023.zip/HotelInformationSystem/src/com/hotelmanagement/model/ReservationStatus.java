package com.hotelmanagement.model;

public enum ReservationStatus {
	WAITING, CONFIRMED, REJECTED, CANCELLED, CHECKED_IN, CHECKED_OUT
}
