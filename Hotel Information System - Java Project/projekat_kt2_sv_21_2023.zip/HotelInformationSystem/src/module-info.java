/**
 * 
 */
/**
 * 
 */
module HotelInformationSystem {
}