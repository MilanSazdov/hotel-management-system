package com.hotelmanagement.model;

public enum ReservationStatus {
	WAITING, CONFIRMED, REJECTED, CANCELLED 
}
