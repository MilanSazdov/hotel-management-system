package com.hotelmanagement.model;

public enum Gender {
	MALE, FEMALE, OTHER, NOT_SPECIFIED
}
